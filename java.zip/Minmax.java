package com.cts.training;
import java.util.*;




int Count = 0;

for(int Number=0; Number< n; Number++)
{ 

    String str = String.valueOf(Number);

   
    for(int i = 0; i < str.length(); i++)
    {
       char c = number.charAt(i);        
       if (c == 1){
       Count++;
       
    }
}
System.out.println(Count);
}

public class Minmax
{
	
public static void main(String[] args)
{

    Scanner sc = new Scanner( System.in );
    int n,i,number;

    n = sc.nextInt( );

    if (0 < n && n < 11 ){ 
    System.out.println("4");
    }
    if (11 <= n && n <= 111){ 
    System.out.println("34");
    }
}
}
}