package com.cts.training;

public class String1 {

	public static void main(String args[]) {
		String msg="i am an enginner";
		String year="of 2020";
		int value=30;

	msg.concat(year);
	System.out.println(msg);
	//Substring(startIndex,int endIndex);
	//Substring(int startindex);
	//substring(8);
	//substring(3,10);
	int index=msg.lastIndexOf('s',5);
	System.out.println(index);
	
	String m=msg.toUpperCase();
	System.out.println(m);
	
	String m1=msg.toLowerCase(); 
	System.out.println(m1);
	
	System.out.println(msg.equals(year));
	
	System.out.println(msg.contains("Hello"));
	
	System.out.println(msg.startsWith("i am"));
	
	System.out.println(msg+"javapoint");
	
	String s=String.valueOf(value);
	System.out.println(s + 10);
	
	String s1="Hello";
	String replaceString=s1.replace('e','h');
	System.out.println(replaceString);
	
	String s2="Helllo";
	System.out.println(s1.compareTo(s2));
	
	System.out.println(s1.trim() +"java");
}
	
}