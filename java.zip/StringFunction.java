package com.cts.training;

public class StringFunction {
	
	public static void main(String args[])
	{
	String str="Global Warming";
	String str1="dfhlo";

	//a) To display the last four characters.

System.out.println(str.substring(str.length()-4,str.length()));


	 //b) To display the substring starting from index 4 and ending at index 8.	
System.out.println(str.substring(4,8));

//  c)To check whether string has alphanumeric characters or not.	 
System.out.println(str.matches("[A-Za-z0-9]+"));

// d)To trim the last four characters from the string.
System.out.println(str.substring(0, str.length()-4));


//e) To trim the first four characters from the string.
System.out.println(str.substring(4));

//f) To display the starting index for the substring "Wa".
System.out.println(str.indexOf("Wa"));

//g) To change the case of the given string
System.out.println(str.toUpperCase());
System.out.println(str.toLowerCase());


//h) To check if the string is in title case.
char result=str1.charAt(0);
if(str1.charAt(0)<=90 && str1.charAt(0)>=65)
{
	System.out.println("string is in title case");
}else {
	System.out.println("string is not in title case");
}


//i) To replace all the occurrences of letter "a" in the string with "*"
System.out.println(str.replaceAll("a","*"));

	}

public boolean isTitleCase(String str)
{
	
	boolean result=false;
	String arr[]=str.split("\\s+");
	for(int i=0;i<arr.length;i++)
	{
		char ch=arr[i].charAt(0);
		if(ch>=65 && ch<=90)
		{
			result=true;
		}else {
			result=false;
			break;
		}}
	return result;

		
	
}

}
