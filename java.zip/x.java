package com.cts.training;

public class x {

	

public static void main(String args[])
{
 
	String city1="pune";
	String city2="pune";
	String city3="mumbai";
	String city4=new String("pune");
	String city5=new String("pune");
	String city6=new String("mumbai");
	System.out.println(city1==city3);
	System.out.println(city3.equals(city6));
	 
	 }
}
