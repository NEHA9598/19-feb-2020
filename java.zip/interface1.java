package com.cts.training;
//package inheritance;
//import java.io.*;

interface interface1 {
	
 int add(int a, int b);
}
class impl implements interface1
{
	public int add(int a,int b)
	{
		return a+b;
	}
}
class interface1
{
	public static void main(String args[])
	{
		impl imp=new impl();
		System.out.println(imp.add(2,3));
	}
}
