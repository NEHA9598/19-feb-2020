package com.cts.training;

class finalkeyword{ 
	

	 static final int age=10;
	 void person()
	 {  
	  age=20;  
	 }  
	 
	 public static void main(String args[])
	 {  
	 finalkeyword obj=new  finalkeyword();  
	 obj.person();  
	 } 
	 }