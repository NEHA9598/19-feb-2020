package com.cts.training;
import java.util.*;

public class Min {

	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no 1");
		int n=sc.nextInt();
		System.out.println("enter no 2");
		int n1=sc.nextInt();
	
		int count=0;
		for(int i=n;i<=n1;i++)
		{
			String number=String.valueOf(i);
			while(number.contains("1"))
			{
				number=number.substring(number.indexOf("1")+1);
				count++;
			}
		}
	
	System.out.println(count);
}
}