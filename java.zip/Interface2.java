package com.cts.training;

//package inheritance;
//import java.io.*;

interface Add{
	public static final int age=20;
 int add(int a, int b);
 default int mul(int a,int b)
 {
	 return a*b;
 }
 

interface sub extends Add
{
  int sub(int a,int b);
	
}
class Div{
	

public int div(int a,int b)
{
	return a/b;
}
}
class impl extends Div implements sub
{
	public int add(int a,int b)
	{
		return a+b;
	}
	
    public int sub(int a,int b)
    {
    	
    	return a-b;
   
    }
}
class Interface2
{
	public static void main(String[]args)
	{
		impl imp=new impl();
		System.out.println(imp.add(2,3));
		System.out.println(imp.sub(8,10));
		System.out.println(imp.div(8,4));
		System.out.println(imp.mul(8,4));
	
	}
}
